/**
 * 
 */
package com.github.banz804.zutil.zutil4j.converter;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.Arrays;

import com.github.banz804.zutil.zutil4j.CobolField;
import com.github.banz804.zutil.zutil4j.ZutilException;
//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypePack;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.PackedDecimal;
import com.github.banz804.zutil.zutil4j.vendor.CobolNumber;
import com.github.banz804.zutil.zutil4j.vendor.ibm.PackedDecimalFormatIBMImpl;

/**
 * @author Kohno Akinori
 *
 */
public class CobolTypeConverterForPackImpl<T extends Number,S extends Number> implements CobolTypeConverter<T,S> {

//	private Object obj = null;
	private Charset charset = null;

	private String fieldName = null;
	
	private int position = 0;
	private int length = 0;
	private Class<?> javaType = null;

//	public CobolTypeConverterForPackImpl(Object obj, Field field, Charset charset){
//		this.obj = obj;
//		//this.charset = charset;
//		
//		this.fieldName = field.getName();
//		this.position = field.getAnnotation(CobolTypePack.class).position();
//		this.length = field.getAnnotation(CobolTypePack.class).length();
//		this.javaType = field.getType();
//	}

	/* class impl 用のメソッド start */
	public CobolTypeConverterForPackImpl(CobolField cobolField, Charset charset){
		this.charset = charset;
		Field field = cobolField.getField();
		
		this.fieldName = field.getName();
		this.position = cobolField.getPosition();
		this.length = field.getAnnotation(PackedDecimal.class).length();
		this.javaType = field.getType();
	}
	public S getValue(T obj,byte[] array) {
		this.setValue(obj,array);
		return this.getValue(obj);
	}
	/* class impl 用のメソッド end */


	private Integer genarateValueAsIntegerFromByteArray(byte[] array) {
		byte[] tempArray = Arrays.copyOfRange(array, this.position, this.position+this.length);

		CobolNumber conv = new PackedDecimalFormatIBMImpl();
		Long temp=null;
		try {
			temp = conv.convertFromByteToLong(tempArray);
		} catch (ZutilException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*
		//整数を作成
		int sum = 0;
		int ketasuu = tempArray.length -1;

		for (int i=0;i<tempArray.length-1 ;i++){ //1
			int temp = tempArray[i]; //TODO シフト演算して整数として取得 0X31->1, 0X32->2, 空白、ゼロは対象外
			if (0x30 <= tempArray[i] && tempArray[i] <=39 ) {
				sum = sum + temp * (int)Math.pow(10, ketasuu-1-i);
			}
		} //1
		*/

		//バリデーション実施
		if (temp < Integer.MIN_VALUE || temp < Integer.MAX_VALUE){
			System.out.println("バリデーションエラー");
		}
		
		//返り値を生成
		Integer result = temp.intValue();
		return result;
	}

	private Long genarateValueAsLongFromByteArray(byte[] array) {
		byte[] tempArray = Arrays.copyOfRange(array, this.position, this.position+this.length);

		//整数を作成
		long sum = 0;
		long ketasuu = tempArray.length -1;

		for (int i=0;i<tempArray.length-1 ;i++){ //1
			int temp = tempArray[i]; //TODO シフト演算して整数として取得 0X31->1, 0X32->2, 空白、ゼロは対象外
			if (0x30 <= tempArray[i] && tempArray[i] <=39 ) {
				sum = sum + (temp-0x30) * (int)Math.pow(10, ketasuu-1-i); 
			}
		} //1

		//バリデーション実施
		
		//返り値を生成
		Long result = new Long(sum);
		return result;
	}

	public void setValue(T obj,byte[] array) {
		String methodType = "set";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    Object result = null;

		Class<?>[] types = null;
		Object value = null;
		if (javaType == Integer.class) { //固有のロジック
			types = new Class[] {Integer.class};	//固有のロジック
			value = this.genarateValueAsIntegerFromByteArray(array);
		} else if (javaType == int.class) { //固有のロジック
				types = new Class[] {int.class};	//固有のロジック
				value = this.genarateValueAsIntegerFromByteArray(array);
		} else if (javaType == Long.class) { //固有のロジック
			types = new Class[] {Long.class};	//固有のロジック
			value = this.genarateValueAsLongFromByteArray(array);
		} else if (javaType == long.class) { //固有のロジック
				types = new Class[] {long.class};	//固有のロジック
				value = this.genarateValueAsLongFromByteArray(array);
		} else {
			// TODO
			System.out.println("想定外の型");
		}

		//メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName, types);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
			result = method.invoke(obj, new Object[] { value });
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}
	}

	public S getValue(T obj) {
		String methodType = "get";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    S result = null;

	    //メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
			result = (S)method.invoke(obj);
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}

		return result;
	}
}
