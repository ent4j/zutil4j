/**
 * 
 */
package com.github.banz804.zutil.zutil4j.converter;

import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.github.banz804.zutil.zutil4j.CobolField;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.G;
import com.github.banz804.zutil.zutil4j.vendor.ibm.ZonedDecimalFormatIBMImpl;

/**
 * それぞれのコンバータを起動するためのプロキシ、実装は持たないものとする。
 * @author Kohno Akinori
 *
 */
public class CobolTypeConvererForGeneral<?,?> implements CobolTypeConverter<T, S> {

	private final boolean  hasValidModifier;
	private CobolTypeConverter<T, S> converter;
	/* class impl 用のメソッド start */
	public CobolTypeConvererForGeneral(CobolField cobolField, Charset charset){
		//this.charset = charset;
		//Field field = cobolField.getField();
		
		//this.fieldName = field.getName();
		//this.position = cobolField.getPosition();
		//this.length = field.getAnnotation(G.class).length();
	    //this.javaType = field.getType();
	    
//	    this.hasSISO = field.getAnnotation(G.class).hasSISO();	
	    
//	    compilePattern(this.modifier,this.length);
		
		CobolTypeConverter<T, S> converter = null;
 
	}

	//修正候補private static final regex1 = "(\\d+)(y)";
	private boolean compilePattern(String str, int length) {
		//match確認、小数部、整数部の取得が目的
		
		//Map<String,Object> map = new HashMap<String,Object>();
		//Key		value（例）
		//整数部		1
		//小数部　	3
		//符号有無 	true
		
		//1. 数値形式
		//S9(5)V99						^(S)9\((\d+)\)V(9+)$							
		//9(5)V99						^9\((\d+)\)V(9+)$
		//S9(5)							^(S)9\((\d+)\)$
		//9(5)			^9.(\d+).  →	^9\((\d+)\)$
				
		//初期化
		this.hasValidModifier = false;
	    //this.seisubu = 0;
	    //this.shosubu = 0;
		//this.hasSigned = false;		
		
//		if (this.modifier != null || this.modifier.equals("")) {
//		//if (this.modifier.equals("NotImplemented")) {
//			this.hasValidModifier = false;
//		    this.zoneDecimal = new ZonedDecimalFormatIBMImpl(false,length,0,this.charset);
//			//this.seisubu = length;			
//		    //this.shosubu = 0;
//			//this.hasSigned = false;		
//			return false;
//		}
		
		String regex1 = "^(S)9\\((\\d+)\\)V(9+)$";
		Pattern p1 = Pattern.compile(regex1);
		Matcher m1 = p1.matcher(str);
		
		if (m1.find() /*&& m1.groupCount()-1 == 3*/){
			this.hasValidModifier = true;
		    this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
		    		true,
		    		Integer.valueOf(m1.group(2)),
    				Integer.valueOf(m1.group(3)),
    				this.charset);
			//this.seisubu = Integer.valueOf(m1.group(2));
		    //this.shosubu = Integer.valueOf(m1.group(3));
			//this.hasSigned = true;
			return true;
		}
		
		String regex2 = "^9\\((\\d+)\\)V(9+)$";
		Pattern p2 = Pattern.compile(regex2);
		Matcher m2 = p2.matcher(str);
		
		if (m2.find() /*&& m1.groupCount()-1 == 3*/){
		    //System.out.println("group" + ":" + m1.group(i));
			this.hasValidModifier = true;
		    this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
		    		false,
		    		Integer.valueOf(m2.group(1)),
		    		Integer.valueOf(m2.group(2)),
    				this.charset);
		    //this.seisubu = Integer.valueOf(m2.group(1));
		    //this.shosubu = Integer.valueOf(m2.group(2));
			//this.hasSigned =false;
			return true;
		}

		String regex3 = "^(S)9\\((\\d+)\\)$";
		Pattern p3 = Pattern.compile(regex3);
		Matcher m3 = p3.matcher(str);

		if (m3.find() /*&& m3.groupCount()-1 == 3*/){
			this.hasValidModifier = true;
			this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
					true,
					Integer.valueOf(m3.group(1)),
		    		0,
    				this.charset);
		    //this.seisubu = Integer.valueOf(m3.group(1));
		    //this.shosubu = 0;
			//this.hasSigned =true;
			return true;
		}
		
		String regex4 = "^9\\((\\d+)\\)$";
		Pattern p4 = Pattern.compile(regex4);
		Matcher m4 = p4.matcher(str);
		
		if (m4.find() /*&& m3.groupCount()-1 == 3*/){
			this.hasValidModifier = true;
			this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
					false,
					Integer.valueOf(m4.group(1)),
		    		0,
    				this.charset);
		    //this.seisubu = Integer.valueOf(m4.group(1));
		    //this.shosubu = 0;
			//this.hasSigned =false;
			return true;
//		} else {
//			System.out.println("正規表現コンパイルエラー");
		}

		return false;
		//String[] regexs = {"(\\d+)(y)","(\\d+)(y)","(\\d+)(y)"};
		/*
		int[] nums = {3,2,2,1};
		String[] regexs = 	{	"^(S)9\\((\\d+)\\)V(9+)$",
								"^9\\((\\d+)\\)V(9+)$",
								"^(S)9\\((\\d+)\\)$",
								"^9\\((\\d+)\\)$"
							};
		
		for (int i=0;i<regexs.length;i++){
			Pattern p = Pattern.compile(regexs[i]);
			Matcher m = p.matcher(str);
			if (m.find() && m.groupCount()-1 == nums[i]){
			    System.out.println("group" + i + ":" + m.group(i));
			    map.put("整数部", Integer.valueOf(m.group(1)));
				map.put("小数部", Integer.valueOf(m.group(2)));
				map.put("符号有無", Boolean.TRUE);
				return map;
			
			/*if (m.find() && m.groupCount()-1 == nums[i]){
				for (int j = 0 ; j < nums[i] ; j++){
				    System.out.println("group" + i + ":" + m.group(i));
				    map.put("整数部", Integer.valueOf(m.group(1)));
					map.put("小数部", Integer.valueOf(m.group(2)));
					return map;
				}
			*/
		/*
		String regex1 = "(\\d+)(y)";
		Pattern p1 = Pattern.compile(regex1);
		Matcher m1 = p1.matcher(str);
		
		String regex2 = "(\\d+)(y)";
		Pattern p2 = Pattern.compile(regex2);
		Matcher m2 = p2.matcher(str);
		
		String regex3 = "(\\d+)(y)";
		Pattern p3 = Pattern.compile(regex3);
		Matcher m3 = p3.matcher(str);
		
		//if (p1.matcher(str).matches()){
		if (m1.find() && m1.groupCount()==3){
			//m.group(0)は対象外
		  for (int i = 1 ; i <= m1.groupCount() ; i++){
			    System.out.println("group" + i + ":" + m1.group(i));
				return null;
			  }

		} else if(m2.find()) {
			return null;
		} else if(m3.find()) {
			return null;
		}
		return null;
		*/
		/*
		String str = "2009year";
		String regex = "(\\d+)(y)";
		Pattern p = Pattern.compile(regex);

		Matcher m = p.matcher(str);
		if (m.find()){
		  String matchstr = m.group();
		  System.out.println(matchstr + "の部分にマッチしました");

		  for (int i = 0 ; i <= m.groupCount() ; i++){
		    System.out.println("group" + i + ":" + m.group(i));
		  }
		}
		*/
		
	} // end of compilePattern

	public S getValue(T obj) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setValue(T obj, byte[] array) {
		// TODO Auto-generated method stub
		
	}

	public S getValue(T obj, byte[] array) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
