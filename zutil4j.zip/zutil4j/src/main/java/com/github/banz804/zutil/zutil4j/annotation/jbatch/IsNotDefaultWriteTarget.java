/**
 * 
 */
package com.github.banz804.zutil.zutil4j.annotation.jbatch;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Kohno Akinori
 *	Moveメソッドはこのアノテーションをfalseに設定すれば、出力対象としない。
 *	集計値をあらわすインスタンスでの使用を想定
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.FIELD)	//フィールドにだけ付けられる指定
public @interface IsNotDefaultWriteTarget {
	boolean value() default false;
}
