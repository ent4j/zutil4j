/**
 * 
 */
package com.github.banz804.zutil.zutil4j;

import java.lang.reflect.Field;
import java.nio.charset.Charset;

//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeG;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypePack;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeX;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeZone;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.G;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.PackedDecimal;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.X;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.ZonedDecimal;
import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverter;
import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForGImpl;
import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForPackImpl;
import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForXImpl;
import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForZoneImpl;

/**
 * @author Kohno Akinori
 *
 */
public class CobolField {
	private final int position;
	private final int length ;
	private final Field field;
	//private final Charset cs;
	private final CobolTypeConverter converter;
	
	CobolField(int position, int length, Field field,Charset cs){
		this.position = position;
		this.length = length;
		this.field = field;
		//this.cs = cs;
		this.converter = selectConverter(this,cs);//this.converter = null; //コンストラクタ内で判定
	}
	public int getPosition() {
		return position;
	}
	public int getLength() {
		return length;
	}

	public CobolTypeConverter getCobolTypeConverter(){
		return converter;
	}
	@SuppressWarnings("rawtypes")
//	@SuppressWarnings("rawtypes")
	private CobolTypeConverter selectConverter(CobolField cobolField,Charset cs) {
//	private CobolTypeConverter<?,?> selectConverter(Field field,Charset cs) {

		//if文判定用条件の取得
	    Class<?> javaType = cobolField.getField().getType();

	    CobolTypeConverter converter = null;
		if (cobolField.getField().getAnnotation(X.class) != null ) {
			
			
			if (javaType == String.class) {
				//フィールド用変換コンバータオブジェクト生成
				//CobolTypeConverterForXImpl<String,String> convX = 
						//ここでposition渡す
				converter=		new CobolTypeConverterForXImpl<String,String>(cobolField,cs); //TODO obj ここはタイプセーフにすべき（優先度低い）
				//値をセット
				//convX.setValue(array);
			} else {
				// TODO
				System.out.println("想定外の型");
			}
		} else if (cobolField.getField().getAnnotation(ZonedDecimal.class) != null) {//TODO Generics型を変数化、アノテーションより取得したい ->　if文をなくせる見込み
			//javaType
			if (javaType == Integer.class || javaType == int.class) {
				//CobolTypeConverterForZoneImpl<Integer,Integer> convN = 
				converter=		new CobolTypeConverterForZoneImpl<Integer,Integer>(cobolField,cs);
				//convN.setValue(array);
			} else if (javaType == Long.class || javaType == long.class) {
				//CobolTypeConverterForZoneImpl<Long,Long> convN = 
				converter=		new CobolTypeConverterForZoneImpl<Long,Long>(cobolField,cs);
				//convN.setValue(array);
			} else {
				// TODO　byte short double float BigDecimalの実装必要
				System.out.println("想定外の型");
			}
			// http://dachihada.hatenablog.com/entry/2013/04/08/195757
				
		} else if (cobolField.getField().getAnnotation(PackedDecimal.class) != null) {
			if (javaType == Integer.class || javaType == int.class) {
				//CobolTypeConverterForPackImpl<Integer,Integer> convN = 
						converter=		new CobolTypeConverterForPackImpl<Integer,Integer>(cobolField,cs);
				//convN.setValue(array);
			} else if (javaType == Long.class || javaType == long.class) {
				//CobolTypeConverterForPackImpl<Long,Long> convN = 
				converter=		new CobolTypeConverterForPackImpl<Long,Long>(cobolField,cs);
				//convN.setValue(array);
			} else {
				// TODO 　byte short double float BigDecimalの実装必要
				System.out.println("想定外の型");
			}
		} else if (cobolField.getField().getAnnotation(G.class) != null) {
			if (javaType == String.class) {
				//フィールド用変換コンバータオブジェクト生成
				//CobolTypeConverterForGImpl<String,String> convX = 
						converter=		new CobolTypeConverterForGImpl<String,String>(cobolField,cs); //TODO obj ここはタイプセーフにすべき（優先度低い）
				//値をセット
				//convX.setValue(array);
			} else {
				// TODO
				System.out.println("想定外の型");
			}

		} else {
			//throw new Exception();
		}
		return converter;

	}
	public Field getField() {
		return field;
	}
	
} //end of class CobolField
