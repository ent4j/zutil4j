/**
 * 
 */
package com.github.banz804.zutil.zutil4j.converter;

//import java.lang.reflect.Field;
//import java.nio.charset.Charset;

//import java.lang.reflect.Field;
//import java.nio.charset.Charset;

//import com.github.banz804.zutil.zutil4j.ZutilException;
//import com.github.banz804.zutil.zutil4j.annotation.CobolType;

/**
 * @author Kohno Akinori
 *
 */
public interface CobolTypeConverter<T,S> {
	//Object obj, Field field, Charset charsetを引数とするコンストラクタを作成すること
	//private XXX genarateValueFromByteArray(byte[] array) 返り値の型毎にメソッド定義	
	public S getValue(T obj); //共通ロジック
	public void setValue(T obj,byte[] array); //型のところだけ違う
	
	/* class impl 用のメソッド start */
	public S getValue(T obj,byte[] array);
	/* class impl 用のメソッド end */

}
