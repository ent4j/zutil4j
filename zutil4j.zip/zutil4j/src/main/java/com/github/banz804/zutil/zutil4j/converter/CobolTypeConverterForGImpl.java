/**
 * 
 */
package com.github.banz804.zutil.zutil4j.converter;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.Arrays;

import com.github.banz804.zutil.zutil4j.CobolField;
//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.G;
//import com.github.banz804.zutil.zutil4j.annotation.HasSISO;

/**
 * @author Kohno Akinori
 * FIXME　high value, low value 判定
 * デフォルトではSISOは付与されていないものとする、必要な場合はHasSISOアノテーションをフィールドに付与する
 * 設定ファイルでのデフォルト値変更を機能追加べきか要検討
 */
public class CobolTypeConverterForGImpl<T,S> implements CobolTypeConverter<T, S>{

//	private Object obj = null;
	private Charset charset = null;

	private String fieldName = null;
	
	private int position = 0;
	private int length = 0;
	private Class<?> javaType = null;
	boolean hasSISO = false;

//	public CobolTypeConverterForGImpl(Object obj, CobolField field, Charset charset){
//		this.obj = obj;
//		this.charset = charset;
//		
//		this.fieldName = field.getField().getName();
//		this.position = field.getPosition();
//		this.length = field.getLength();
//	    this.javaType = field.getField().getType();
//	    
//	    this.hasSISO = field.getField().getAnnotation(G.class).hasSISO();
//	}


	/* class impl 用のメソッド start */
	public CobolTypeConverterForGImpl(CobolField cobolField, Charset charset){
		this.charset = charset;
		Field field = cobolField.getField();
		
		this.fieldName = field.getName();
		this.position = cobolField.getPosition();
		this.length = field.getAnnotation(G.class).length();
	    this.javaType = field.getType();
	    
	    this.hasSISO = field.getAnnotation(G.class).hasSISO();		
	}
	public S getValue(T obj,byte[] array) {
		this.setValue(obj,array);
		return this.getValue(obj);
	}
	/* class impl 用のメソッド end */

	//TODO SI,SOを考慮した実装必要
	private String genarateValueAsStringFromByteArray(byte[] array) {
		byte[] tempArray = null;
		String result=null;
						
		if (this.hasSISO == false) {

			int lengthOfSource = this.length;
			int lengthOfTarget = this.length + 2; //(plus 0x0E and 0x0F)
			int startPosition = this.position;
			//int endPosition = this.position+this.length;
			tempArray = new byte[lengthOfTarget];
			for (int i=0;i<lengthOfSource;i++){
				tempArray[i+1] = array[startPosition+i];
			}
			tempArray[0] = (byte)0x0E;
			tempArray[lengthOfTarget-1] = (byte)0x0F;
					
			int SIposition = this.position; //position of 0x0E
			int SOposition = this.position+this.length-1; //position of 0x0E
	    	if (array[SIposition]==(byte)0x0E && array[SOposition]==(byte)0x0F) {
	    		System.out.println("SISOがすでに存在する");
	    	}
			
		} else if (this.hasSISO  == true) {
			int SIposition = this.position; //position of 0x0E
			int SOposition = this.position+this.length-1; //position of 0x0F
	    	if (array[SIposition]==(byte)0x0E && array[SOposition]==(byte)0x0F) {
	    		tempArray=Arrays.copyOfRange(array, SIposition, SOposition+1);
	    	} else {
	    		System.out.println("SISOがない");
	    	}
		}
		result = new String(tempArray,this.charset);			
	    return result;
	} //1

	public void setValue(T obj,byte[] array) {
		String methodType = "set";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    Object result = null;

		Class<?>[] types = null;
		Object value = null;
		if (javaType == String.class) { //固有のロジック
			types = new Class[] {String.class};	//固有のロジック
			value = this.genarateValueAsStringFromByteArray(array);
		} else {
			// TODO
			System.out.println("想定外の型");
		}

		//メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName, types);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
	    	result = method.invoke(obj, new Object[] { value });
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
}

	/* (non-Javadoc)
	 * @see com.github.banz804.zutil.zutil4j.converter.CobolTypeConverter#getValue(byte[], int, int, java.nio.charset.Charset)
	 */
	@SuppressWarnings("unchecked")
	public S getValue(T obj) {
		String methodType = "get";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    S result = null;

	    //メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
			result = (S)method.invoke(obj);
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}

		return result;
	}
}
