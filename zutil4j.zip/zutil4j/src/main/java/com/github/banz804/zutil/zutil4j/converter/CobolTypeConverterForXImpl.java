/**
 * 
 */
package com.github.banz804.zutil.zutil4j.converter;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.Arrays;

import com.github.banz804.zutil.zutil4j.CobolField;
//import com.github.banz804.zutil.zutil4j.annotation.CopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeX;
//import com.github.banz804.zutil.zutil4j.annotation.CobolType;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.X;

/**
 * @author Kohno Akinori
 *
 */
public class CobolTypeConverterForXImpl<T,S> implements CobolTypeConverter<T, S> {

	//private Object obj = null;
	private Charset charset = null;

	private String fieldName = null;
	
	private int position = 0;
	private int length = 0;
	private Class<?> javaType = null;
	
//	public CobolTypeConverterForXImpl(Object obj, Field field, Charset charset){
//		this.obj = obj;
//		this.charset = charset;
//		
//		this.fieldName = field.getName();
//		this.position = field.getAnnotation(CobolTypeX.class).position();
//		this.length = field.getAnnotation(CobolTypeX.class).length();
//		this.javaType = field.getType();
//		
//	}	

	/* class impl 用のメソッド start */
	public CobolTypeConverterForXImpl(CobolField cobolField, Charset charset){
		//this.obj = obj;
		this.charset = charset;
		Field field = cobolField.getField();
		
		this.fieldName = field.getName();
		this.position = cobolField.getPosition();
		this.length = field.getAnnotation(X.class).length();
		this.javaType = field.getType();
		
	}	

	public S getValue(T obj,byte[] array) {
		//Class<?> clazz = S.newInstance();//S.class;
		
		this.setValue(obj,array);
		return this.getValue(obj);
	}
	/* class impl 用のメソッド end */

	private String genarateValueFromByteArray(byte[] array) {
		byte[] tempArray = Arrays.copyOfRange(array, this.position, this.position+this.length);

		String result = new String(tempArray,this.charset);
		return result;
	}

	public void setValue(T obj,byte[] array) {
		
		String methodType = "set";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    Object result = null;

		Class<?>[] types = null;
		Object value = null;
		if (javaType == String.class) { //固有のロジック
			types = new Class[] {String.class};	//固有のロジック
			value = this.genarateValueFromByteArray(array/*, position, length , charset TODO need*/);
		} else {
			// TODO
			System.out.println("想定外の型");
		}

		//メソッドの取得
	   try {
			method = obj.getClass().getMethod(methodName, types);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
	    	
	    	result = method.invoke(obj, new Object[] { value });
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public S getValue(T obj) {
		String methodType = "get";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    S result = null;

		//メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
			result = (S)method.invoke(obj);
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}

		return result;
	}

	
	
}
