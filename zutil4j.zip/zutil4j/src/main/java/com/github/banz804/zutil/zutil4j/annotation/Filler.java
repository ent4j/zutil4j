/**
 * 
 */
package com.github.banz804.zutil.zutil4j.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * @author Kohno Akinori
 *
 */
@Retention(RetentionPolicy.RUNTIME) //これを付与しないと実行時にannotationを取得できない
@Target(ElementType.FIELD)	//フィールドにだけ付けられる指定
public @interface Filler {
	int order();
	//int position(); //orderとlengthがあれば計算できるので削除
	int length();
}
