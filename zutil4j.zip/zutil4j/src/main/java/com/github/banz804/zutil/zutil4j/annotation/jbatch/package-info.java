/**
 * 
 */
/**
 * @author Kohno Akinori
 *
 */
package com.github.banz804.zutil.zutil4j.annotation.jbatch;