package com.github.banz804.zutil.zutil4j.annotation.jbatch;
/**
 * 
 * @author Kohno Akinori
 *	自動で入力ソースからMoveしたくない項目に対して設定、Moveメソッドはこのアノテーションがなければ名前が一致するものを自動でMoveする
 *	必要なところだけ記述すればいいようにする
 */

public @interface DoNotMove {
	//boolean value() default true;
}
