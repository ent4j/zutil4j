/**
 * 
 */
package com.github.banz804.zutil.zutil4j.converter;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.github.banz804.zutil.zutil4j.CobolField;
import com.github.banz804.zutil.zutil4j.ZutilException;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeZone;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.ZonedDecimal;
import com.github.banz804.zutil.zutil4j.vendor.ibm.ZonedDecimalFormatIBMImpl;

//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;

/**
 * @author Kohno Akinori
 *
 */
public class CobolTypeConverterForZoneImpl<T extends Number,S extends Number> implements CobolTypeConverter<T,S > {
	//CobolTypeConverterForZoneImpl.class.getDeclaredFields();
	//private Object obj = null;
	private Charset charset = null;

	private String fieldName = null;
	
	private int position = 0;
	private int length = 0;
	//private String modifier = null;
	private Class<?> javaType = null;
	
	private boolean hasValidModifier = false;
	private ZonedDecimalFormatIBMImpl zoneDecimal =null;
//	private boolean hasSigned = false;
//	private int seisubu = 0;
//	private int shosubu = 0;
	//private int numBase = 0; 

//	public CobolTypeConverterForZoneImpl(Object obj, Field field, Charset charset){
//		this.obj = obj;
//		this.charset = charset;
//		
//		this.fieldName = field.getName();
//		this.position = field.getAnnotation(CobolTypeZone.class).position();
//		this.length = field.getAnnotation(CobolTypeZone.class).length();
//	    this.modifier = field.getAnnotation(CobolTypeZone.class).modifier();
//	    /*this.pattern = */
//	    //this.pattern
//	    this.javaType = field.getType();
//	    
//	    compilePattern(this.modifier,this.length);
//	}

	/* class impl 用のメソッド start */
	public CobolTypeConverterForZoneImpl(CobolField cobolField, Charset charset){
//		this.obj = obj;
		this.charset = charset;
		Field field = cobolField.getField();
		
		this.fieldName = field.getName();
		this.position = cobolField.getPosition();
		this.length = field.getAnnotation(ZonedDecimal.class).length();
	    //this.modifier = field.getAnnotation(ZonedDecimal.class).modifier();
	    this.javaType = field.getType();
	    
	    //compilePattern(this.modifier,this.length);
	}
	public S getValue(T obj,byte[] array) {
		this.setValue(obj,array);
		return this.getValue(obj);
	}
	/* class impl 用のメソッド end */

	//修正候補private static final regex1 = "(\\d+)(y)";
	private boolean compilePattern(String str, int length) {
		//match確認、小数部、整数部の取得が目的
		
		//Map<String,Object> map = new HashMap<String,Object>();
		//Key		value（例）
		//整数部		1
		//小数部　	3
		//符号有無 	true
		
		//1. 数値形式
		//S9(5)V99						^(S)9\((\d+)\)V(9+)$							
		//9(5)V99						^9\((\d+)\)V(9+)$
		//S9(5)							^(S)9\((\d+)\)$
		//9(5)			^9.(\d+).  →	^9\((\d+)\)$
				
		//初期化
		this.hasValidModifier = false;
	    //this.seisubu = 0;
	    //this.shosubu = 0;
		//this.hasSigned = false;		
		
//		if (this.modifier != null || this.modifier.equals("")) {
//		//if (this.modifier.equals("NotImplemented")) {
//			this.hasValidModifier = false;
//		    this.zoneDecimal = new ZonedDecimalFormatIBMImpl(false,length,0,this.charset);
//			//this.seisubu = length;			
//		    //this.shosubu = 0;
//			//this.hasSigned = false;		
//			return false;
//		}
		
		String regex1 = "^(S)9\\((\\d+)\\)V(9+)$";
		Pattern p1 = Pattern.compile(regex1);
		Matcher m1 = p1.matcher(str);
		
		if (m1.find() /*&& m1.groupCount()-1 == 3*/){
			this.hasValidModifier = true;
		    this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
		    		true,
		    		Integer.valueOf(m1.group(2)),
    				Integer.valueOf(m1.group(3)),
    				this.charset);
			//this.seisubu = Integer.valueOf(m1.group(2));
		    //this.shosubu = Integer.valueOf(m1.group(3));
			//this.hasSigned = true;
			return true;
		}
		
		String regex2 = "^9\\((\\d+)\\)V(9+)$";
		Pattern p2 = Pattern.compile(regex2);
		Matcher m2 = p2.matcher(str);
		
		if (m2.find() /*&& m1.groupCount()-1 == 3*/){
		    //System.out.println("group" + ":" + m1.group(i));
			this.hasValidModifier = true;
		    this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
		    		false,
		    		Integer.valueOf(m2.group(1)),
		    		Integer.valueOf(m2.group(2)),
    				this.charset);
		    //this.seisubu = Integer.valueOf(m2.group(1));
		    //this.shosubu = Integer.valueOf(m2.group(2));
			//this.hasSigned =false;
			return true;
		}

		String regex3 = "^(S)9\\((\\d+)\\)$";
		Pattern p3 = Pattern.compile(regex3);
		Matcher m3 = p3.matcher(str);

		if (m3.find() /*&& m3.groupCount()-1 == 3*/){
			this.hasValidModifier = true;
			this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
					true,
					Integer.valueOf(m3.group(1)),
		    		0,
    				this.charset);
		    //this.seisubu = Integer.valueOf(m3.group(1));
		    //this.shosubu = 0;
			//this.hasSigned =true;
			return true;
		}
		
		String regex4 = "^9\\((\\d+)\\)$";
		Pattern p4 = Pattern.compile(regex4);
		Matcher m4 = p4.matcher(str);
		
		if (m4.find() /*&& m3.groupCount()-1 == 3*/){
			this.hasValidModifier = true;
			this.zoneDecimal = new ZonedDecimalFormatIBMImpl(
					false,
					Integer.valueOf(m4.group(1)),
		    		0,
    				this.charset);
		    //this.seisubu = Integer.valueOf(m4.group(1));
		    //this.shosubu = 0;
			//this.hasSigned =false;
			return true;
//		} else {
//			System.out.println("正規表現コンパイルエラー");
		}

		return false;
		//String[] regexs = {"(\\d+)(y)","(\\d+)(y)","(\\d+)(y)"};
		/*
		int[] nums = {3,2,2,1};
		String[] regexs = 	{	"^(S)9\\((\\d+)\\)V(9+)$",
								"^9\\((\\d+)\\)V(9+)$",
								"^(S)9\\((\\d+)\\)$",
								"^9\\((\\d+)\\)$"
							};
		
		for (int i=0;i<regexs.length;i++){
			Pattern p = Pattern.compile(regexs[i]);
			Matcher m = p.matcher(str);
			if (m.find() && m.groupCount()-1 == nums[i]){
			    System.out.println("group" + i + ":" + m.group(i));
			    map.put("整数部", Integer.valueOf(m.group(1)));
				map.put("小数部", Integer.valueOf(m.group(2)));
				map.put("符号有無", Boolean.TRUE);
				return map;
			
			/*if (m.find() && m.groupCount()-1 == nums[i]){
				for (int j = 0 ; j < nums[i] ; j++){
				    System.out.println("group" + i + ":" + m.group(i));
				    map.put("整数部", Integer.valueOf(m.group(1)));
					map.put("小数部", Integer.valueOf(m.group(2)));
					return map;
				}
			*/
		/*
		String regex1 = "(\\d+)(y)";
		Pattern p1 = Pattern.compile(regex1);
		Matcher m1 = p1.matcher(str);
		
		String regex2 = "(\\d+)(y)";
		Pattern p2 = Pattern.compile(regex2);
		Matcher m2 = p2.matcher(str);
		
		String regex3 = "(\\d+)(y)";
		Pattern p3 = Pattern.compile(regex3);
		Matcher m3 = p3.matcher(str);
		
		//if (p1.matcher(str).matches()){
		if (m1.find() && m1.groupCount()==3){
			//m.group(0)は対象外
		  for (int i = 1 ; i <= m1.groupCount() ; i++){
			    System.out.println("group" + i + ":" + m1.group(i));
				return null;
			  }

		} else if(m2.find()) {
			return null;
		} else if(m3.find()) {
			return null;
		}
		return null;
		*/
		/*
		String str = "2009year";
		String regex = "(\\d+)(y)";
		Pattern p = Pattern.compile(regex);

		Matcher m = p.matcher(str);
		if (m.find()){
		  String matchstr = m.group();
		  System.out.println(matchstr + "の部分にマッチしました");

		  for (int i = 0 ; i <= m.groupCount() ; i++){
		    System.out.println("group" + i + ":" + m.group(i));
		  }
		}
		*/
		
	} // end of compilePattern
	
	
//	private Integer genarateValueAsIntegerFromByteArray(byte[] array, int positionVal, int lengthVal, boolean hasValidModifierVal, boolean hasSignedVal) {
//		
//		//IBMの符号表現
//		//1234  -> 0xF1F2F3F4
//		//+1234 -> 0xF1F2F3C4
//		//-1234 -> 0xF1F2F3D4
//
//		int sum = 0;
//
//		//整数部の計算
//		//byte[] tempArray = Arrays.copyOfRange(array, this.position, this.position+this.length);
//		byte[] tempArray = Arrays.copyOfRange(array, positionVal, positionVal+lengthVal);
//
//		//整数を作成
//		int ketasuu = this.seisubu;//tempArray.length;
//
//		for (int i=0;i<ketasuu/*tempArray.length*/ ;i++){ //1
//			int temp = tempArray[i] & 0xFF; //TODO シフト演算して整数として取得 0X31->1, 0X32->2, 空白、ゼロは対象外
//			temp = temp - getNumBaseInt();
//			if (0 <= temp && temp <= 9 ) {
//				sum = sum + temp * (int)Math.pow(10, ketasuu-i-1);
//			}
//
//			/*
//			byte temp = tempArray[i]; //TODO シフト演算して整数として取得 0X31->1, 0X32->2, 空白、ゼロは対象外
//			if (0x30 <= tempArray[i] && tempArray[i] <= 0x39 ) {
//				sum = sum + (temp - 0x30) * (int)Math.pow(10, ketasuu-i-1);
//			}
//			*/
//		} //1
//
//		//小数部の計算
//		if (this.shosubu > 0){
//			byte[] tempArray2 = Arrays.copyOfRange(array, positionVal+this.seisubu, positionVal+this.shosubu);
//			
//			int shosuKetasuu = this.shosubu;//tempArray.length;
//			
//			for (int i=0;i<shosuKetasuu;i++){ //1
//				int temp = tempArray2[i] & 0xFF; //TODO シフト演算して整数として取得 0X31->1, 0X32->2, 空白、ゼロは対象外
//				temp = temp - getNumBaseInt();
//				if (0 <= temp && temp <= 9 ) {
//					sum = sum + temp * (int)Math.pow(10, -1 * (i+1));
//				}
//			} //1
//		}
//			
//		//最後のバイトの前半の処理
//		if (hasSignedVal == true) {
//			int intSignedValue = tempArray[positionVal+lengthVal-1] & 0xFF;
//			intSignedValue = intSignedValue >>>4;
//			if (intSignedValue == 0x0000000C) {//正の数
//			} else if (intSignedValue == 0x0000000D) { //負の数
//				sum = sum * (-1);
//			} else {
//				//エラー TODO
//				//System.out.println("a "+intHugo);
//				try {
//					throw new ZutilException();
//				} catch (ZutilException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//					//throw e;
//				}
//			}
//		} else {
//			
//		}
//
//
//		//バリデーション実施
//		
//		//返り値を生成
//		//Integer result = new Integer(sum);
//		return sum;
//	}

	private Long genarateValueAsLongFromByteArray(byte[] array, boolean hasValidModifier2, boolean hasSigned2) {
		byte[] tempArray = Arrays.copyOfRange(array, this.position, this.position+this.length);

		//整数を作成
		long sum = 0;
		long ketasuu = tempArray.length;

		for (int i=0;i<tempArray.length ;i++){ //1
			long temp = tempArray[i] & 0xFF; //TODO シフト演算して整数として取得 0X31->1, 0X32->2, 空白、ゼロは対象外
			temp = temp - getNumBaseLong();
			if (0 <= temp && temp <= 9 ) {
				sum = sum + temp * (long)Math.pow(10, ketasuu-1-i); 
			}
		} //1

		//バリデーション実施
		
		//返り値を生成
		//Long result = new Long(sum);
		return sum;
	}
	/*
	private int getNumBaseInt() {
		int result = 0;
		if (charset.name().equals("x-IBM930") == true) {
			//int intUpper = array[i] & 0xFF;
			result = 0xF0 & 0xFF;
		} else {
			result = 0x30 & 0xFF;
		}
		return result; 
	}*/

	
	private long getNumBaseLong() {
		long result = 0;
		if (charset == null) {
			//int intUpper = array[i] & 0xFF;
			result = 0xF0 & 0xFFFF;
		} else {
			result = 0x30 & 0xFFFF;
		}
		return result; 
	}

	/*
	private <T> T getNumBase() {
		T result = 0;
		if (charset == null) {
			//int intUpper = array[i] & 0xFF;
			result = 0xF0 & 0xFF;
		} else {
			result = 0x30 & 0xFF;
		}
		return result; 
	}
	*/

	public void setValue(T obj,byte[] array) {
		String methodType = "set";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    Object result = null;

		Class<?>[] types = null;
		Object value = null;
		if (javaType == Integer.class) { //固有のロジック
			types = new Class[] {Integer.class};	//固有のロジック
			//value = this.genarateValueAsIntegerFromByteArray(array,this.position,this.length,this.hasValidModifier,this.hasSigned);
			value = this.zoneDecimal.genarateValueAsIntegerFromByteArray(array, this.position, this.length);
		} else if (javaType == int.class) { //固有のロジック
				types = new Class[] {int.class};	//固有のロジック
				//value = this.genarateValueAsIntegerFromByteArray(array,this.position,this.length,this.hasValidModifier,this.hasSigned);
				value = this.zoneDecimal.genarateValueAsIntegerFromByteArray(array, this.position, this.length);
		} else if (javaType == Long.class) { //固有のロジック
				types = new Class[] {Long.class};	//固有のロジック
				value = this.genarateValueAsLongFromByteArray(array,this.hasValidModifier,true); //FIXME /*this.hasSigned*/);
		} else if (javaType == long.class) { //固有のロジック
			types = new Class[] {Long.class};	//固有のロジック
			value = this.genarateValueAsLongFromByteArray(array,this.hasValidModifier,true);//FIXME this.hasSigned);
		//FIXME short byte bigdecimal対応必要
		} else {
			// TODO
			System.out.println("想定外の型");
		}

		//メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName, types);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
	    	result = method.invoke(obj, new Object[] { value });
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public S getValue(T obj) {
		String methodType = "get";
		String methodName = methodType + 
	    					fieldName.substring(0,1).toUpperCase() + 
	    					fieldName.substring(1);
	    
	    Method method = null;
	    S result = null;

	    //メソッドの取得
	    try {
			method = obj.getClass().getMethod(methodName);
		} catch (NoSuchMethodException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SecurityException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	    
	    //メソッドの実行
	    try {
			result = (S)method.invoke(obj); //@SuppressWarnings("unchecked")
		} catch (IllegalAccessException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (IllegalArgumentException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		} catch (InvocationTargetException e1) {
			// TODO Auto-generated catch block
			System.out.println(result);
			e1.printStackTrace();
		}

		return result;
	}

}
