package com.github.banz804.zutil.zutil4j;

import java.util.Iterator;
import java.util.List;

public interface FixRecordDefinitionBean<T> extends Iterator<T>  {

	//必要なメソッド、このクラスの存在意義、責務
	//public abstract T getFilledObject();
	
	public abstract T getInstance(byte[] b);

	public abstract List<T> getInstances(byte[] b);
	
	public abstract String getFixRecordDefinition();

	public abstract void printlnFixRecordDefinition();

	public abstract int getRecordLength();
}