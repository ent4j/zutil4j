package com.github.banz804.zutil.zutil4j.annotation.coboltype;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME) //これを付与しないと実行時にannotationを取得できない
@Target(ElementType.FIELD)	//フィールドにだけ付けられる指定
public @interface X {
	int order();
	int length();
	String description() default "";

}
