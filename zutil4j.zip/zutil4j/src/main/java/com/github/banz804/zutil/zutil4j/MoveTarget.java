/**
 * 
 */
package com.github.banz804.zutil.zutil4j;

/**
 * @author Kohno Akinori
 *
 */
public interface MoveTarget<T> {
	public abstract void moveFrom(T obj);
}
