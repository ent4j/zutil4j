/**
 * 
 */
package com.github.banz804.zutil.zutil4j;

import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeG;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypePack;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeX;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeZone;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.G;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.PackedDecimal;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.X;
//import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverter;
//import com.github.banz804.zutil.zutil4j.annotation.CopyClause;
//import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForGImpl;
//import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForPackImpl;
//import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForXImpl;
//import com.github.banz804.zutil.zutil4j.converter.CobolTypeConverterForZoneImpl;
import com.github.banz804.zutil.zutil4j.annotation.coboltype.ZonedDecimal;

/**
 * @author Kohno Akinori
 * @param <T>
 *
 */
public class FixRecordDefinitionBeanClassImpl<T> implements
		FixRecordDefinitionBean<T> {
	
	//--- field -------------------------------------------------------------------
	//private T obj = null;
	//private byte[] array = null;
	private static final String zutilDefaultCharset = "x-IBM930";
	private Charset charset = Charset.forName(zutilDefaultCharset);
	private final Class<?> clazz;
	private final int recordLength;
	private final List<CobolField> fields;
	
	//--- constructor -------------------------------------------------------------
	public FixRecordDefinitionBeanClassImpl(Class<?> clazz) {
		this(clazz,getExternalDefinedCahrset());
	}

	/**
	 * priority fix value -> file -> argument
	 * ここで、必要なフィールドへのセットが完了する、このコンストラクタ以外でのセットは禁止する。呼び出しているprivateメソッドも他の場所でしようしてはならない
	 * @param obj
	 * @param array
	 * @param cs
	 */
	public FixRecordDefinitionBeanClassImpl(Class<?> clazz,Charset cs) {
		getExternalDefinedCahrset(cs);
		//this.setProperties();
		this.clazz = clazz;/*clazz.getInterfaces()*/
		this.charset = cs;
		//setOrderedFields(array);
		this.recordLength = this.getRecordLength();

		//インスタンス化時にレコードのレイアウト（メタ情報）をCobolField型にキャッシュ
		List<Integer> lengths = this.getFieldLengths(getOrderedFields());
		List<Integer> positions = this.getFieldLengths(getOrderedFields());
		this.fields = this.initCobolFields(lengths,positions,this.getOrderedFields(),cs);
		/*
		List<Integer> lengths = this.getFieldLengths(getOrderedFields());
		this.setCobolFieldLengths(lengths, fields);
		List<Integer> positions = this.getFieldLengths(getOrderedFields());
		this.setCobolFieldPositions(positions, fields);
		*/
	}
	
//	getExternalDefinedCahrset

	//--- public method -----------------------------------------------------------
	@SuppressWarnings("unchecked") 
	public T getInstance(byte[] array) /*throws ZutilException*/ {
		//レコード長チェック
		if (array.length != this.recordLength) {
			System.out.println("不正なレコード長");
			throw new RuntimeException();
		}
		
		T obj =null;;
		try {
			obj = (T)clazz.newInstance();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		for (int i=0;i<fields.size();i++){
			//fields.get(i).getCobolTypeConverter().setValue(array);
			fields.get(i).getCobolTypeConverter().getValue(obj, array);
		}
		
		return obj;//null;
	}
		
//	@SuppressWarnings("unchecked")
//	public T BkgetInstance(byte[] array) /*throws ZutilException*/ {
//		// TODO FixRecordDefinitionBeanInstanceImpl#setOrderedFieldsを実装
//		
//		//レコード長チェック
//		if (array.length != this.recordLength) {
//			System.out.println("不正なレコード長");
//			throw new RuntimeException();
//		}
//		
//		List<Field> fields = getOrderedFields();
//		T obj =null;;
//		try {
//			obj = (T)clazz.newInstance();
//		} catch (InstantiationException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IllegalAccessException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//
//		for (int i=0;i<fields.size();i++){
//			Field field = fields.get(i);
//			
//			//if文判定用条件の取得
//		    Class<?> javaType = field.getType();
//		    		    
//			if (field.getAnnotation(CobolTypeX.class) != null ) {
//				if (javaType == String.class) {
//					//フィールド用変換コンバータオブジェクト生成
//					CobolTypeConverterForXImpl<String,String> convX = 
//							//ここでposition渡す
//							new CobolTypeConverterForXImpl<String,String>(obj, field,this.charset); //TODO obj ここはタイプセーフにすべき（優先度低い）
//					//値をセット
//					convX.setValue(array);
//				} else {
//					// TODO
//					System.out.println("想定外の型");
//				}
//			} else if (field.getAnnotation(CobolTypeZone.class) != null) {//TODO Generics型を変数化、アノテーションより取得したい ->　if文をなくせる見込み
//				//javaType
//				if (javaType == Integer.class || javaType == int.class) {
//					CobolTypeConverterForZoneImpl<Integer,Integer> convN = 
//							new CobolTypeConverterForZoneImpl<Integer,Integer>(obj, field,this.charset);
//					convN.setValue(array);
//				} else if (javaType == Long.class || javaType == long.class) {
//					CobolTypeConverterForZoneImpl<Long,Long> convN = 
//							new CobolTypeConverterForZoneImpl<Long,Long>(obj, field,this.charset);
//					convN.setValue(array);
//				} else {
//					// TODO　byte short double float BigDecimalの実装必要
//					System.out.println("想定外の型");
//				}
//				// http://dachihada.hatenablog.com/entry/2013/04/08/195757
//					
//			} else if (field.getAnnotation(CobolTypePack.class) != null) {
//				if (javaType == Integer.class || javaType == int.class) {
//					CobolTypeConverterForPackImpl<Integer,Integer> convN = 
//							new CobolTypeConverterForPackImpl<Integer,Integer>(obj, field,this.charset);
//					convN.setValue(array);
//				} else if (javaType == Long.class || javaType == long.class) {
//					CobolTypeConverterForPackImpl<Long,Long> convN = 
//							new CobolTypeConverterForPackImpl<Long,Long>(obj, field,this.charset);
//					convN.setValue(array);
//				} else {
//					// TODO 　byte short double float BigDecimalの実装必要
//					System.out.println("想定外の型");
//				}
//			} else if (field.getAnnotation(CobolTypeG.class) != null) {
//				if (javaType == String.class) {
//					//フィールド用変換コンバータオブジェクト生成
//					CobolTypeConverterForGImpl<String,String> convX = 
//							new CobolTypeConverterForGImpl<String,String>(obj, field,this.charset); //TODO obj ここはタイプセーフにすべき（優先度低い）
//					//値をセット
//					convX.setValue(array);
//				} else {
//					// TODO
//					System.out.println("想定外の型");
//				}
//
//			} else {
//				//throw new Exception();
//			}
//
//		}
//
//		//end
//		return obj;//null;
//	}

	public List<T> getInstances(byte[] array) {
		List<T> list = null;
		int arrayLength = array.length; 
		//long recordLength = getRecordLength()
		if (arrayLength % this.recordLength != 0) {
			return new ArrayList<T>();
		}
		
		int nums = arrayLength / this.recordLength;
		list = new ArrayList<T>(nums);
		for (long i= 0;i<nums;i++) {
			byte[] tempArray = Arrays.copyOfRange(
					array, 
					0+nums*this.recordLength, 
					0+(nums+1)*this.recordLength);
			list.add(this.getInstance(tempArray));
		}
		return  list;
	}

	public String getFixRecordDefinition() {
		// TODO Auto-generated method stub
		return null;
	}

	public void printlnFixRecordDefinition() {
		List<Field> fields = getOrderedFields();
		for (int i=0;i<fields.size();i++){
			System.out.println(fields.get(i).toString());
		}
	}
	
	//--- private method ---------------------------------------------------------	
	static private Charset getExternalDefinedCahrset() {
		
        InputStream is = null;
        Properties props = null;
		try {
			java.net.URL url = FixRecordDefinitionBeanClassImpl.class.getResource("/zutil4j.properties");
			if (url != null) {
				is = FixRecordDefinitionBeanClassImpl.class.getResourceAsStream("/zutil4j.properties");
		        props = new Properties();
	
		        props.load(is);
		        is.close();
			
				if (props.containsKey("charset")) {
					return Charset.forName(props.getProperty("charset"));
				}
	        }
		} catch (Exception ex) {
			System.out.println("読込でエラー発生");
			System.out.println(ex.getMessage() );
			ex.printStackTrace();
		} 
		
		return Charset.forName(zutilDefaultCharset);
	}

	static private Charset getExternalDefinedCahrset(Charset cs) {
		
		if (cs != null ) {
			return cs;
		}
		
        InputStream is = null;
        Properties props = null;
		try {
			String str = System.getProperty("ZUTIL4J_PROPERTYIES_PATH");
			if (str != null) {
				java.net.URL url = FixRecordDefinitionBeanClassImpl.class.getResource(str/*"/zutil4j.properties"*/); //FIXME zutil4j.propertiesはjar外のファイルにするので、システムプロパティから取得するように要変更
				if (url != null) {
					is = FixRecordDefinitionBeanClassImpl.class.getResourceAsStream(str/*"/zutil4j.properties"*/); //FIXME zutil4j.propertiesはjar外のファイルにするので、システムプロパティから取得するように要変更
			        props = new Properties();
		
			        props.load(is);
			        is.close();
				
					if (props.containsKey("charset")) {
						return Charset.forName(props.getProperty("charset"));
					}
		        }
			}
		} catch (Exception ex) {
			System.out.println("読込でエラー発生");
			System.out.println(ex.getMessage() );
			ex.printStackTrace();
		} 
		
		return Charset.forName(zutilDefaultCharset);
	}

	private List<Field> getOrderedFields() {//FIXME annotation がnull
		
		if (this.clazz == null ) {
			throw new RuntimeException();
		}
		
	    Map<Integer,Field> map = new HashMap<Integer,Field>(); 
		for (Field field : clazz.getDeclaredFields()) {
    		if(field.getAnnotation(G.class) != null ) {
//    		if(field.getAnnotation(CobolTypeG.class) != null ) {
    			int order = field.getAnnotation(G.class).order();
    			map.put(order,field);
    		} else if(field.getAnnotation(X.class) != null ) {
//    		} else if(field.getAnnotation(CobolTypeX.class) != null ) {
            		int order = field.getAnnotation(X.class).order();
        		map.put(order,field);
    		} else if(field.getAnnotation(ZonedDecimal.class) != null ) {
//    		} else if(field.getAnnotation(CobolTypeZone.class) != null ) {
            		int order = field.getAnnotation(ZonedDecimal.class).order();
        		map.put(order,field);
    		} else if(field.getAnnotation(PackedDecimal.class) != null ) {
//    		} else if(field.getAnnotation(CobolTypePack.class) != null ) {
        		int order = field.getAnnotation(PackedDecimal.class).order();
        		map.put(order,field);
    		}
	    }

		ArrayList<Field> fields = new ArrayList<Field>(map.size()); 
		for (int i=0;i<map.size();i++){
			Field field = map.get(i);
			fields.add(field);
		}
		return fields;
	}
	
//	private List<CobolField> setCobolFields() {
	private List<CobolField> initCobolFields(List<Integer> positions, List<Integer> lengths,
												List<Field> fields,
												Charset cs) {
		//if (this.fields !=null) {
		//	return this.fields; //キャッシュの仕組み導入
		//} else {
			//List<Field> fields = this.getOrderedFields();
			List<CobolField> cobolFields = new ArrayList<CobolField>();
			//List<Integer> positions = this.getFieldPositions(fields);
			//List<Integer> lengths FIXME not implemented
			for(int i=0;i<fields.size();i++){
				cobolFields.add(new CobolField(
										positions.get(i),
										positions.get(i),
										fields.get(i),
										cs)
								);
			}
			return cobolFields;
		//}
	}

	private List<Integer> getFieldLengths(List<Field> fields) {

		List<Integer> lengths = new ArrayList<Integer>();
		
		for (int i=0;i<fields.size();i++){
			Field field = fields.get(i);
    		if(field.getAnnotation(G.class) != null ) {
    			int length = field.getAnnotation(G.class).length();
    			lengths.add(length);
    		} else if(field.getAnnotation(X.class) != null ) {
        		int length = field.getAnnotation(X.class).length();
    			lengths.add(length);
    		} else if(field.getAnnotation(ZonedDecimal.class) != null ) {
        		int length = field.getAnnotation(ZonedDecimal.class).length();
    			lengths.add(length);
    		} else if(field.getAnnotation(PackedDecimal.class) != null ) {
        		int length = field.getAnnotation(PackedDecimal.class).length();
        		lengths.add(length);
    		}
		}

		return lengths;
	}
	
	private List<Integer> getFieldPositions(List<Field> fields) {
		//List<Field> fields = this.getOrderedFields();
		
		List<Integer> positions = new ArrayList<Integer>();
		
		int position = 0;
		
		//ArrayList<Field> fields = this.getOrderedFields();
		
		//ArrayList<Integer> positions = new ArrayList<Integer>(map.size()); 
		for (int i=0;i<fields.size();i++){
			Field field = fields.get(i);
    		if(field.getAnnotation(G.class) != null ) {
    			int length = field.getAnnotation(G.class).length();
    			position = position + length;
    			positions.add(position);
    		} else if(field.getAnnotation(X.class) != null ) {
        		int length = field.getAnnotation(X.class).length();
    			position = position + length;
    			positions.add(position);
    		} else if(field.getAnnotation(ZonedDecimal.class) != null ) {
        		int length = field.getAnnotation(ZonedDecimal.class).length();
    			position = position + length;
    			positions.add(position);
    		} else if(field.getAnnotation(PackedDecimal.class) != null ) {
        		int length = field.getAnnotation(PackedDecimal.class).length();
    			position = position + length;
    			positions.add(position);
    		}

//			position = position + fields.get(i).getAnnotationsByType(annotationClass);
			positions.add(position);
		}

			
		return positions;
	}

	/*
	private void setCobolFieldLengths(List<Integer> lengths,List<CobolField>cobolFields) {
		for (int i=0;i<cobolFields.size();i++){
			cobolField.get(i).setlengths.get(i))
		}
	}
	
	private void setCobolFieldPositions(List<Integer> lengths,List<CobolField>cobolFields) {
		for (int i=0;i<cobolFields.size();i++){
			
		}
	}*/
	/*
	
	//positionを自動計算するために追加、アノテーションは残しておいてよいのではないか
	private List<CobolTypeConverter> getFieldConverters() {
		List<CobolTypeConverter> list = new ArrayList<CobolTypeConverter>();
			
		return list;
	}
*/
	
	public int getRecordLength() {
		//clazz.getAnnotation(CopyClause.class).length();
		int sum = 0;
		List<Field> fields = getOrderedFields();
		for (int i=0;i<fields.size();i++){
//			fields.get(i).getAnnotation(CobolTypeG.class).length();
			if (fields.get(i).getAnnotation(X.class) != null ) {
				sum = sum +fields.get(i).getAnnotation(X.class).length();
			} else if (fields.get(i).getAnnotation(ZonedDecimal.class) != null) {//TODO Generics型を変数化、アノテーションより取得したい ->　if文をなくせる見込み
				sum = sum +fields.get(i).getAnnotation(ZonedDecimal.class).length();
			} else if (fields.get(i).getAnnotation(PackedDecimal.class) != null) {
				sum = sum +fields.get(i).getAnnotation(PackedDecimal.class).length();
			} else if (fields.get(i).getAnnotation(G.class) != null) {
				sum = sum +fields.get(i).getAnnotation(G.class).length();
			} else {
				//throw new Exception();
			}
		}
		return sum;
	}

	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	public T next() {
		// TODO Auto-generated method stub
		return null;
	}

}
