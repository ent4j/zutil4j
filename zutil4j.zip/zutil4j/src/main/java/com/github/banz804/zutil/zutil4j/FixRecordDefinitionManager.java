/**
 * 
 */
package com.github.banz804.zutil.zutil4j;

/**
 * @author Kohno Akinori
 *
 */
public class FixRecordDefinitionManager {

}
