/**
 * 
 */
package com.github.banz804.zutil.zutil4j.annotation;
import java.lang.annotation.ElementType;
import java.lang.annotation.Target;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * @author Kohno Akinori
 *
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE)	//型（クラス）にだけ付けられる指定
public @interface CopyClause {
	int level() default 0;
	String description() default "";
	int occurs() default 1;
}
