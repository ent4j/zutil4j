/**
 * 
 */
/**
 * @author Kohno Akinori
 *　テストに必要なBeanを格納
 */
package com.github.banz804.zutil.zutil4j.util.test;