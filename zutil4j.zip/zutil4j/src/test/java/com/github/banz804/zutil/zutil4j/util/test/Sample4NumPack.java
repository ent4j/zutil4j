package com.github.banz804.zutil.zutil4j.util.test;

//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeEnum;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypeZone;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypePack;

public class Sample4NumPack {

	@CobolTypeZone(order=0,position=0,length=3)
	private int foo = 0;
	@CobolTypePack(order=1,position=3,length=2)
	public int bar = 0;
	@CobolTypeZone(order=2,position=5,length=3)
	public int zoo = 0;
	
	public void setFoo(int val) {
		foo = val;
	}

	public int getFoo(){
		return foo;
	}

	public void setBar(int val) {
		bar = val;
	}

	public int getBar(){
		return bar;
	}

	public void setZoo(int val) {
		zoo = val;
	}

	public int getZoo(){
		return zoo;
	}

}
