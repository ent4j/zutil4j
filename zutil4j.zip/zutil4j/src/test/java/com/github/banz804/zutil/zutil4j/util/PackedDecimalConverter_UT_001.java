/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.github.banz804.zutil.zutil4j.ZutilException;
import com.github.banz804.zutil.zutil4j.vendor.CobolNumber;
import com.github.banz804.zutil.zutil4j.vendor.ibm.PackedDecimalFormatIBMImpl;

//import java.util.

/**
 * @author Kohno Akinori
 *
 */
public class PackedDecimalConverter_UT_001 {

	//@Test
	public void test() {
		fail("Not yet implemented");
	}

	//@Test
	public void test2() {
		fail("2 Not yet implemented");
	}

	@Test
	public void 初めてのテスト() {
		/*byte[] temp = new byte[3];
		temp[0]=1;
		temp[1]=2;
		temp[2]=127;
*/
		byte[] temp = new byte[1];
		temp[0]=0x09;
//		temp[1]=0x3c;
//		temp[2]=127;

		CobolNumber pack = new PackedDecimalFormatIBMImpl();
		long result =0;// pack.convertFromByteToLong(temp);
		//result = pack.convertFromByteToLong(temp);
		
		///assertEquals(0,result);

		temp[0]=0x3c;
		try {
			result = pack.convertFromByteToLong(temp);
		} catch (ZutilException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(3,result);

		temp[0]=0x3d;
		try {
			result = pack.convertFromByteToLong(temp);
		} catch (ZutilException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(-3,result);

	}
	//@Test
	public void convertFromByteToLong(/*byte[] array*/) {
		//　zero origin
		byte[] array = {1};
		int arraySize = array.length - 1;
		int lastposition = arraySize - 1;
		
		byte signedValue = array[arraySize - 1];// & (byte)0x0F;
		//X byte signedValue = array[arraySize - 1] & 0x000F;
		//X char a = signedValue;
		if (signedValue <0) {//負の数の場合
			int signedValueAsIntL = array[arraySize - 1];
			int signedValueAsIntH = array[arraySize - 1];
			//下4桁取得
			signedValueAsIntL = signedValueAsIntL  & 0x0000000F;
			byte signedValueAsByteL= (byte)signedValueAsIntL; //答え　要確認 TODO
			
			//上4桁
			signedValueAsIntH = signedValueAsIntH  & 0x80000070;
			signedValueAsIntH = signedValueAsIntH  >>>4;
			byte signedValueAsByteH= (byte)signedValueAsIntH; //答え　要確認 TODO
		} else{//整数なら>>>は使える
			//
		}
		
		//**************************
		//符号の取得 シフト演算はint型
		//byte signedValue = array[arraySize - 1] & (byte)0x0F;
		//int signedValue = array[arraySize - 1] & (byte)0x0F;
		
		//intへのキャストので負数の場合、先頭2バイトが1で拡張（埋め込み）されてしまう可能性あり、
		//char型へのキャストが望ましいのではないか
		//ボツ char signedValueAsChar =  (char)array[arraySize - 1] & (char)0x0F;
		
		
		//下位4ビットの取得 シフト演算はint型
		//byte a = signedValue & 0x0F;
		//signedValue >>> 4;
		//TODO 一時的にintを使用しているが、byte->intの段階でビットが狂っている可能性があるため、正しい実装を行う必要あり。
		//int a = signedValue & 0x0F;
		//signedValue = signedValue >>> 4;
		
		/*
		String signedValueAsString = null;
		if (signedValue == 0x0C) {
			signedValueAsString = "+";
		} else if (signedValue == 0x0D) {
			signedValueAsString = "-";
		} else {
			//throw new Exception();
		}
		
		*/
		String valueAsString = null;
		//バイト配列から数値を取得(先頭0バイト目から、後ろから2つ目まで、最後のバイトは上記のように符号を表す)
		for (int i=0;i< arraySize - 2;i++) {
			valueAsString = valueAsString + String.valueOf(array[i]);
		}

		//arraySize - 1の処理、第1桁目の処理 
		
		//return Long.valueOf(signedValueAsString + valueAsString);
	}

	//@Test
	public void convertFromByteToLongハッシュで事前に持っておく() {
		Map<Byte,Byte[]> map = new HashMap<Byte,Byte[]>();
		
//		map.set(new Byte(1),new Byte[] {new Byte(1),new Byte(1)});
//		map.put((byte)1,new Byte[] {1,2});
//		map.put(new Byte("1"),new Byte[] {1,2});
//		map.put(new Byte((byte)1),new Byte[] {1,2});

//		map.put(new Byte(123),new Byte[] {1,2});
//		map.put(new Byte(1),new Byte[]);
//		map.set(new Byte(1),new Byte[]);

//		map.put((byte)-129,new Byte[] {1,2}); //0xFFFF
		//TODO とりうる値をすべて定義する
		map.put((byte)-128,new Byte[] {1,2});
		map.put((byte)-127,new Byte[] {1,2});
		map.put((byte)-99,new Byte[] {1,2});
		map.put((byte)-1,new Byte[] {1,2});
		map.put((byte)0,new Byte[] {1,2});//0x0000
		map.put((byte)1,new Byte[] {1,2});
		map.put((byte)2,new Byte[] {1,2});
		map.put((byte)3,new Byte[] {1,2});
		map.put((byte)100,new Byte[] {1,2});
		map.put((byte)-126,new Byte[] {1,2});
		map.put((byte)-127,new Byte[] {1,2});//0x7F
		
		//入力データの作成
		byte[] temp = new byte[3];
		temp[0]=1;
		temp[1]=2;
		temp[2]=127;
				
		long sum =0L;

		//長さゼロの場合
		if (temp.length == 0) { //4-1
			//何もしないでリターン//エラー TODO
		} else { //4-1,4-2
			//数値部分の取得
			int ketasuu = temp.length*2 -1;
			if (temp.length > 1) { //3
				for (int i=0;i<temp.length ;i++){ //1
						sum = sum + map.get(temp[i])[0] * (long)Math.pow(10, ketasuu-i) 
								  + map.get(temp[i])[1] * (long)Math.pow(10, ketasuu-i+1);
					} //1
			}//3
			
			//最終桁の処理
			sum = sum + map.get(temp[temp.length])[0]; //aと同義

			//符号の取得
			byte hugo= map.get(temp[temp.length-1])[1];
			//String hugoStr =null;
			if (hugo == 0x0C) {//正の数
				//hugoStr="+";
			} else if (hugo == 0x0D) { //負の数
				sum = sum * (-1);
				//hugoStr="-";
			} else {
				//エラー TODO
			}
		} //4-2
		//return sum;
	} //func end

}
