package com.github.banz804.zutil.zutil4j.util.test;

//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeEnum;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypePack;

public class Sample3Pack {
	@CobolTypePack(order=0,position=0,length=3)
	public int zoo = 0;
	
	public void setZoo(int val) {
		zoo = val;
	}

	public int getZoo(){
		return zoo;
	}

}
