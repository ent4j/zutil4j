/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.github.banz804.zutil.zutil4j.ZutilException;
import com.github.banz804.zutil.zutil4j.vendor.ibm.PackedDecimalFormatIBMImpl;

/**
 * @author Kohno Akinori
 *
 */
public class PackedDecimalConverter_UT_002 {

	//@Test
	public void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void N01_配列のテスト() {
		byte[] temp = new byte[3];
		temp[0]=0x11;
		temp[1]=0x12;
		temp[2]=(byte)0x3c;
		//temp[2]=99;
		//0000 0000 桁数 二進数
		//3210 3210 基数
		//8421 8421 
		
		//十進で9
		//java byte配列の2進表示
		//1001 1001


		long result1=0;
		try {
			result1 = new PackedDecimalFormatIBMImpl().convertFromByteToLong(temp);
		} catch (ZutilException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(11123,result1);
	}

	@Test
	public void N01_配列のテスト2() {
		byte[] temp = new byte[]{(byte)0x06, (byte)0x59, (byte)0x97,(byte)0x3d};

		long result1=0;
		try {
			result1 = new PackedDecimalFormatIBMImpl().convertFromByteToLong(temp);
		} catch (ZutilException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		assertEquals(-659973,result1);
	}
}
