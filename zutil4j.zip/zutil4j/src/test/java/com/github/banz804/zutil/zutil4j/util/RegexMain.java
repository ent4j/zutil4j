/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author Kohno Akinori
 *
 */
public class RegexMain {

	/**
	 * @param args
	 * http://www.javadrive.jp/regex/ref/index2.html
	 */
	public static void main(String[] args) {
		String str = "2009year";
		String regex = "(\\d+)(y)";
		Pattern p = Pattern.compile(regex);

		Matcher m = p.matcher(str);
		if (m.find()){
		  String matchstr = m.group();
		  System.out.println(matchstr + "の部分にマッチしました");

		  for (int i = 0 ; i <= m.groupCount() ; i++){
		    System.out.println("group" + i + ":" + m.group(i));
		  }
		}

	}

}
