package com.github.banz804.zutil.zutil4j.util.test;

public interface TestProtected {

	/*protected*/ boolean isPrintTarget = false;
}
