/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import static org.junit.Assert.*;

import org.junit.Test;


/**
 * @author Kohno Akinori
 *
 */
public class CobolTypeConverter_UT_001 {


}
