package com.github.banz804.zutil.zutil4j.util.test;

//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeEnum;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypeG;
//import com.github.banz804.zutil.zutil4j.annotation.HasSISO;

public class Sample7G_SISO {
	//@HasSISO(true)
	@CobolTypeG(order=0,
			position=0,
			length=4,
			description="テスト4バイト文字型",
			hasSISO=true)
	public String bar = null;
	
	public void setBar(String val) {
		bar = val;
	}

	public String getBar(){
		return bar;
	}

}
