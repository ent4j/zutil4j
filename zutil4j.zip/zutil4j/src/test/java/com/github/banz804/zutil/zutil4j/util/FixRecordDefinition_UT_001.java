/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.github.banz804.zutil.zutil4j.FixRecordDefinitionBean;
import com.github.banz804.zutil.zutil4j.FixRecordDefinitionBeanInstanceImpl;
import com.github.banz804.zutil.zutil4j.util.test.Sample;
import com.github.banz804.zutil.zutil4j.util.test.Sample2;
import com.github.banz804.zutil.zutil4j.util.test.Sample3Pack;
import com.github.banz804.zutil.zutil4j.util.test.Sample4NumPack;
import com.github.banz804.zutil.zutil4j.util.test.Sample5NumX;
import com.github.banz804.zutil.zutil4j.util.test.Sample6G;
import com.github.banz804.zutil.zutil4j.util.test.Sample7G_NOSISO;
import com.github.banz804.zutil.zutil4j.util.test.Sample7G_SISO;
import com.github.banz804.zutil.zutil4j.util.test.Sample8_IntModifier;

/**
 * @author Kohno Akinori
 *
 */
public class FixRecordDefinition_UT_001 {

	@Test
	public void test1_Sample_Num() {
		Sample sample = new Sample();
		byte[] array = null;
		array = new byte[3];
		
		array[0]= (byte)0xF1;
		array[1]= (byte)0xF2;
		array[2]= (byte)0xF3;
/*		array[0]= (byte)0x31;
		array[1]= (byte)0x32;
		array[2]= (byte)0x33;
*/		
		FixRecordDefinitionBeanInstanceImpl<Sample> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample>(sample,array);
		
		Sample result = fix.getFilledObject();
		
		//assertEquals(100,result.zoo);
		assertEquals(123,result.zoo);
				
	}

	@Test
	public void test2() {
		Sample2 sample2 = new Sample2();
		byte[] array = null;
		array = new byte[6];
		
		array[0]= (byte)0xF1;
		array[1]= (byte)0xF2;
		array[2]= (byte)0xF3;
		array[3]= (byte)0xF4;
		array[4]= (byte)0xF5;
		array[5]= (byte)0xF6;

/*		array[0]= (byte)0x31;
		array[1]= (byte)0x32;
		array[2]= (byte)0x33;
		array[3]= (byte)0x34;
		array[4]= (byte)0x35;
		array[5]= (byte)0x36;
*/
		FixRecordDefinitionBeanInstanceImpl<Sample2> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample2>(sample2,array);
		
		Sample2 result = fix.getFilledObject();
		
		//assertEquals(100,result.zoo);
		assertEquals(123,result.zoo);
		assertEquals(456,result.getBar());
				
	}

	@Test
	public void test3_Sample3Pack_Pack() {
		Sample3Pack sample3 = new Sample3Pack();
		byte[] array = null;
		array = new byte[3];
		
		array[0]= (byte)0x12;
		array[1]= (byte)0x34;
		array[2]= (byte)0x5C;

		FixRecordDefinitionBeanInstanceImpl<Sample3Pack> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample3Pack>(sample3,array);
		
		Sample3Pack result = fix.getFilledObject();
		
		assertEquals(12345,result.getZoo());
				
	}
	
	@Test
	public void test4() {
		Sample3Pack sample3 = new Sample3Pack();
		byte[] array = null;
		array = new byte[3];
		
		array[0]= (byte)0x34;
		array[1]= (byte)0x56;
		array[2]= (byte)0x7D;

		FixRecordDefinitionBeanInstanceImpl<Sample3Pack> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample3Pack>(sample3,array);
		
		Sample3Pack result = fix.getFilledObject();
		
		assertEquals(-34567,result.getZoo());
				
	}

	@Test
	public void test5_Sample4NumPack_NumPack() {
		Sample4NumPack sample4 = new Sample4NumPack();
		byte[] array = {
				(byte)0xF4,
				(byte)0xF5,
				(byte)0xF6,
				(byte)0x12,
				(byte)0x3C,
				(byte)0xF7,
				(byte)0xF7,
				(byte)0xF7
		};
	//		byte[] array = null;
//		array = new byte[8];
		
/*		array[0]= (byte)0xF4;
		array[1]= (byte)0xF5;
		array[2]= (byte)0xF6;
		array[3]= (byte)0x12;
		array[4]= (byte)0x3C;
		array[5]= (byte)0xF7;
		array[6]= (byte)0xF7;
		array[7]= (byte)0xF7;
*/
		FixRecordDefinitionBeanInstanceImpl<Sample4NumPack> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample4NumPack>(sample4,array);
		
		Sample4NumPack result = fix.getFilledObject();
		
		assertEquals(456,result.getFoo());
		assertEquals(123,result.getBar());
		assertEquals(777,result.getZoo());
				
	}
	
	@Test
	public void test5_Sample5NumX() {
		Sample5NumX sample5 = new Sample5NumX();
		byte[] array = {
				(byte)0xF4,
				(byte)0xF5,
				(byte)0xF6,
				(byte)0xF1,
				(byte)0x82
		};

		FixRecordDefinitionBeanInstanceImpl<Sample5NumX> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample5NumX>(sample5,array);
		
		Sample5NumX result = fix.getFilledObject();
		
		assertEquals(456,result.getFoo());
		
		//assertEquals("1ｱ",result.getBar());
		//assertEquals("1a",result.getBar());
		assertEquals("1ｲ",result.getBar());
				
	}

	@Test
	public void test5_Sample6G() {
		Sample6G sample6 = new Sample6G();
		byte[] array = {
				//(byte)0x0E,
				(byte)0x65,
				(byte)0x93//,
				//(byte)0x0F
		};

		FixRecordDefinitionBeanInstanceImpl<Sample6G> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample6G>(sample6,array);
		
		Sample6G result = fix.getFilledObject();
		
		assertEquals("鈐",result.getBar());
				
	}

	@Test
	public void test6_Sample7G() {
		Sample7G_SISO sample7 = new Sample7G_SISO();
		byte[] array = {
				(byte)0x0E,
				(byte)0x65,
				(byte)0x93,
				(byte)0x0F
		};

		FixRecordDefinitionBeanInstanceImpl<Sample7G_SISO> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample7G_SISO>(sample7,array);
		
		Sample7G_SISO result = fix.getFilledObject();
		
		assertEquals("鈐",result.getBar());
				
	}

	@Test
	public void test8_Sample7G_NOSISO() {
		Sample7G_NOSISO sample7 = new Sample7G_NOSISO();
		byte[] array = {
				//(byte)0x0E,
				(byte)0x65,
				(byte)0x93//,
				//(byte)0x0F
		};

		FixRecordDefinitionBeanInstanceImpl<Sample7G_NOSISO> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample7G_NOSISO>(sample7,array);
		
				Sample7G_NOSISO result = fix.getFilledObject();
		
		assertEquals("鈐",result.getBar());
				
	}

	@Test
	public void test8_Sample_Num() {
		Sample8_IntModifier sample = new Sample8_IntModifier();
		byte[] array = {
				(byte)0xF1,
				(byte)0xF2,
				(byte)0xF3,
				(byte)0xF4
		};
		
		FixRecordDefinitionBeanInstanceImpl<Sample8_IntModifier> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample8_IntModifier>(sample,array);
		
		Sample8_IntModifier result = fix.getFilledObject();
		
		assertEquals(1234,result.zoo);
				
	}

}
