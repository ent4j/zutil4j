/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

/**
 * @author Kohno Akinori
 *
 */
public class ConvertByteFrom127To255 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println("00-09");
		System.out.println(String.format("%02X",(byte)0x00));

		//http://masao6739.blog89.fc2.com/blog-entry-21.html
		/*
		byte byteValue = (byte) 0xFF;
        int intValue1 = byteValue;
        System.out.println(String.format("byte型 byteValue (16進数表示):%X", byteValue));
        System.out.println(String.format("byte型 byteValue (10進数表示):%d", byteValue));
        System.out.println(String.format("int型 intValue1 (16進数表示):%X", intValue1));
        System.out.println(String.format("int型 intValue1 (10進数表示):%d", intValue1));
    
		 */
		
//      byte型 byteValue (16進数表示):FF
//      byte型 byteValue (10進数表示):-1
//      int型 intValue1 (16進数表示):FFFFFFFF
//      int型 intValue1 (10進数表示):-1
		
//		javaの制約
//		javaはbyteでシフト演算できない
//		intキャスト後の負の数のシフト演算は値がくるう
//		intの正の数しか正しいシフト演算はできない
//		解決方法はキャスト前に0xFF
		
        byte byteValue = (byte) 0xFF;
        int intValue1 = byteValue;
        int intValue2 = byteValue & 0xFF;
        System.out.println(String.format("byte型 byteValue (16進数表示):%X", byteValue));
        System.out.println(String.format("byte型 byteValue (10進数表示):%d", byteValue));
        System.out.println(String.format("int型 intValue1 (16進数表示):%X", intValue1));
        System.out.println(String.format("int型 intValue1 (10進数表示):%d", intValue1));
        System.out.println(String.format("int型 intValue2 (16進数表示):%08X", intValue2));
        System.out.println(String.format("int型 intValue2 (10進数表示):%d", intValue2));
   

//        byte型 byteValue (16進数表示):FF
//        byte型 byteValue (10進数表示):-1
//        int型 intValue1 (16進数表示):FFFFFFFF
//        int型 intValue1 (10進数表示):-1
//        int型 intValue2 (16進数表示):000000FF
//        int型 intValue2 (10進数表示):255
	}

}
