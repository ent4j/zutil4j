/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import java.util.Iterator;

/**
 * @author Kohno Akinori
 * @param <E>
 *
 */
public class TestIteratorImpl<E> implements Iterator<E> {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}

	public E next() {
		// TODO Auto-generated method stub
		return null;
	}

}
