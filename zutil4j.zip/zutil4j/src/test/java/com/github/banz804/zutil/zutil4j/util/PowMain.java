/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

/**
 * @author Kohno Akinori
 *
 */
public class PowMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	    double a = 10d;
	    double b = 2d;

	    System.out.println("「" + a + "」の「" + b + "」乗は");
	    System.out.println("「" + Math.pow(a, b) + "」です。");

	    double c = 10d;
	    double d = -2d;

	    System.out.println("「" + c + "」の「" + d + "」乗は");
	    System.out.println("「" + Math.pow(c, d) + "」です。");

	    double e = 10d;
	    double f = -0d;

	    System.out.println("「" + e + "」の「" + f + "」乗は");
	    System.out.println("「" + Math.pow(e, f) + "」です。");
	    
	}

}
