package com.github.banz804.zutil.zutil4j.util.test;

//import com.github.banz804.zutil.zutil4j.annotation.CobolCopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeEnum;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypeZone;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypeX;

public class Sample5NumX {

	@CobolTypeZone(order=0,position=0,length=3)
	private int foo = 0;
	@CobolTypeX(order=1,position=3,length=2)
	public String bar = null;
	
	public void setFoo(int val) {
		foo = val;
	}

	public int getFoo(){
		return foo;
	}

	public void setBar(String val) {
		bar = val;
	}

	public String getBar(){
		return bar;
	}

}
