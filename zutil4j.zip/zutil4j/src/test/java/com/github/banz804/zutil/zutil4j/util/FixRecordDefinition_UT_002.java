/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

import static org.junit.Assert.*;

import org.junit.Test;

import com.github.banz804.zutil.zutil4j.FixRecordDefinitionBean;
import com.github.banz804.zutil.zutil4j.FixRecordDefinitionBeanClassImpl;
import com.github.banz804.zutil.zutil4j.FixRecordDefinitionBeanInstanceImpl;
import com.github.banz804.zutil.zutil4j.util.test.Sample;
//import com.github.banz804.zutil.zutil4j.util.test.Sample2;
//import com.github.banz804.zutil.zutil4j.util.test.Sample3Pack;
//import com.github.banz804.zutil.zutil4j.util.test.Sample4NumPack;
//import com.github.banz804.zutil.zutil4j.util.test.Sample5NumX;
//import com.github.banz804.zutil.zutil4j.util.test.Sample6G;
//import com.github.banz804.zutil.zutil4j.util.test.Sample7G_NOSISO;
//import com.github.banz804.zutil.zutil4j.util.test.Sample7G_SISO;
//import com.github.banz804.zutil.zutil4j.util.test.Sample8_IntModifier;
import com.github.banz804.zutil.zutil4j.util.test.Sample2;
import com.github.banz804.zutil.zutil4j.util.test.Sample3Pack;
import com.github.banz804.zutil.zutil4j.util.test.Sample4NumPack;
import com.github.banz804.zutil.zutil4j.util.test.Sample5NumX;
import com.github.banz804.zutil.zutil4j.util.test.Sample6G;
import com.github.banz804.zutil.zutil4j.util.test.Sample7G_SISO;
import com.github.banz804.zutil.zutil4j.util.test.Sample8_IntModifier;

/**
 * @author Kohno Akinori
 *
 */
public class FixRecordDefinition_UT_002 {

	@Test
	public void test1_Sample_Num_基本_ひとつのフィールドを処理する() {
		Sample sample = new Sample();
		byte[] array = null;
		array = new byte[3];
		
		array[0]= (byte)0xF1;
		array[1]= (byte)0xF2;
		array[2]= (byte)0xF3;

		FixRecordDefinitionBean<Sample> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample>(Sample.class);
		
		Sample result = fix.getInstance(array);
		
		//assertEquals(100,result.zoo);
		assertEquals(123,result.zoo);
				
	}
	
	@Test
	public void test2_Sample2_連続するフィールドのテスト() {
		Sample2 sample2 = new Sample2();
		byte[] array = null;
		array = new byte[6];
		
		array[0]= (byte)0xF1;
		array[1]= (byte)0xF2;
		array[2]= (byte)0xF3;
		array[3]= (byte)0xF4;
		array[4]= (byte)0xF5;
		array[5]= (byte)0xF6;

		FixRecordDefinitionBean<Sample2> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample2>(Sample2.class);
		
		Sample2 result = fix.getInstance(array);
		
		//assertEquals(100,result.zoo);
		assertEquals(123,result.zoo);
		assertEquals(456,result.getBar());
				
	}

	@Test
	public void test3_Sample3Pack_Pack型のテスト() {
		Sample3Pack sample3 = new Sample3Pack();
		byte[] array = null;
		array = new byte[3];
		
		array[0]= (byte)0x12;
		array[1]= (byte)0x34;
		array[2]= (byte)0x5C;

		FixRecordDefinitionBean<Sample3Pack> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample3Pack>(Sample3Pack.class);
		
		Sample3Pack result = fix.getInstance(array);
		
		assertEquals(12345,result.getZoo());
				
	}

	@Test
	public void test4_Sample3Pack_Pack形式で負の数の取り扱いをする() {
		Sample3Pack sample3 = new Sample3Pack();
		byte[] array = null;
		array = new byte[3];
		
		array[0]= (byte)0x34;
		array[1]= (byte)0x56;
		array[2]= (byte)0x7D;

		FixRecordDefinitionBean<Sample3Pack> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample3Pack>(Sample3Pack.class);
		
		Sample3Pack result = fix.getInstance(array);
		
		assertEquals(-34567,result.getZoo());
				
	}

	@Test
	public void test5_Sample4NumPack_NumPack_ZoneとPackの組み合わせ() {
		Sample4NumPack sample4 = new Sample4NumPack();
		byte[] array = {
				(byte)0xF4,
				(byte)0xF5,
				(byte)0xF6,
				(byte)0x12,
				(byte)0x3C,
				(byte)0xF7,
				(byte)0xF7,
				(byte)0xF7
		};

		FixRecordDefinitionBean<Sample4NumPack> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample4NumPack>(Sample4NumPack.class);
		
		Sample4NumPack result = fix.getInstance(array);
		
		assertEquals(456,result.getFoo());
		assertEquals(123,result.getBar());
		assertEquals(777,result.getZoo());
				
	}

	@Test
	public void test6_Sample5NumX_Zoneとシングルバイト文字の組み合わせ() {
		Sample5NumX sample5 = new Sample5NumX();
		byte[] array = {
				(byte)0xF4,
				(byte)0xF5,
				(byte)0xF6,
				(byte)0xF1,
				(byte)0x82
		};

		FixRecordDefinitionBean<Sample5NumX> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample5NumX>(Sample5NumX.class);
		
		Sample5NumX result = fix.getInstance(array);
		
		assertEquals(456,result.getFoo());
		
		assertEquals("1ｲ",result.getBar());
				
	}
	
	@Test
	public void test7_Sample6G_SISOなしのダブルバイト文字のテスト() {
		Sample6G sample6 = new Sample6G();
		byte[] array = {
				(byte)0x65,
				(byte)0x93
		};

		FixRecordDefinitionBean<Sample6G> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample6G>(Sample6G.class);
		
		Sample6G result = fix.getInstance(array);
		
		assertEquals("鈐",result.getBar());
				
	}

	@Test
	public void test8_Sample7G_SISO_SISOありのダブルバイト文字のテスト() {
		//Sample7G_SISO sample7 = new Sample7G_SISO();
		byte[] array = {
				(byte)0x0E,
				(byte)0x65,
				(byte)0x93,
				(byte)0x0F
		};

		FixRecordDefinitionBean<Sample7G_SISO> fix = 
				new FixRecordDefinitionBeanClassImpl<Sample7G_SISO>(Sample7G_SISO.class);
		
		Sample7G_SISO result = fix.getInstance(array);
		
		assertEquals("鈐",result.getBar());
				
	}
	
	@Test
	public void test9_Sample8_IntModifier_ゾーン十進テスト() {
		Sample8_IntModifier sample = new Sample8_IntModifier();
		byte[] array = {
				(byte)0xF1,
				(byte)0xF2,
				(byte)0xF3,
				(byte)0xF4
		};
		
		FixRecordDefinitionBeanInstanceImpl<Sample8_IntModifier> fix = 
				new FixRecordDefinitionBeanInstanceImpl<Sample8_IntModifier>(sample,array);
		
		Sample8_IntModifier result = fix.getFilledObject();
		
		assertEquals(1234,result.zoo);
				
	}


}
