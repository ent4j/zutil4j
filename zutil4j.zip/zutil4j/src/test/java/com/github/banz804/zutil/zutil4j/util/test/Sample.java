/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util.test;

import com.github.banz804.zutil.zutil4j.annotation.CopyClause;
//import com.github.banz804.zutil.zutil4j.annotation.CobolTypeEnum;
import com.github.banz804.zutil.zutil4j.annotation.CobolTypeZone;

/**
 * @author Kohno Akinori
 *
 */
@CopyClause
public class Sample {
/*
	@Order(1)
	@Length(4)
	@Type(CobolType.X)
	@Description("テスト")
	int foo =0;
	
	@Order(2)
	@Length(2)
	@Type(CobolType.X)
	@Description("テスト2")
	int bar =0;
*/

	//こちらの定義のほうが一行に収まっていて構文解析しやすい
	@CobolTypeZone(order=0,position=0,length=3,description="テスト3"/*, TypeModifier = "X(9)"*/, modifier = "")
	public int zoo = 0;
	
	public void setZoo(int val) {
		zoo = val;
	}

	public int getZoo(){
		return zoo;
	}
//	@CobolCopyClause(order=1,position=0,length=3,type=CobolType.X,description="テスト3"/*, TypeModifier = "X(9)"*/)
//	int zoo = 0;

}
