/**
 * 
 */
package com.github.banz804.zutil.zutil4j.util;

/**
 * @author Kohno Akinori
 *
 */
public class DumpHex {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println("00-09");
		System.out.println(String.format("%02X",(byte)0x00));
		System.out.println(String.format("%02X",(byte)0x01));
		System.out.println(String.format("%02X",(byte)0x02));
		System.out.println(String.format("%02X",(byte)0x03));
		System.out.println(String.format("%02X",(byte)0x04));
		System.out.println(String.format("%02X",(byte)0x05));
		System.out.println(String.format("%02X",(byte)0x06));
		System.out.println(String.format("%02X",(byte)0x07));
		System.out.println(String.format("%02X",(byte)0x08));
		System.out.println(String.format("%02X",(byte)0x09));
//		System.out.println(String.format("%02X",(byte)0x0A));

		System.out.println("10-19");
		System.out.println(String.format("%02X",(byte)0x10));
		System.out.println(String.format("%02X",(byte)0x11));
		System.out.println(String.format("%02X",(byte)0x12));
		System.out.println(String.format("%02X",(byte)0x13));
		System.out.println(String.format("%02X",(byte)0x14));
		System.out.println(String.format("%02X",(byte)0x15));
		System.out.println(String.format("%02X",(byte)0x16));
		System.out.println(String.format("%02X",(byte)0x17));
		System.out.println(String.format("%02X",(byte)0x18));
		System.out.println(String.format("%02X",(byte)0x19));
		
		System.out.println("20-29");
		System.out.println(String.format("%02X",(byte)0x20));
		System.out.println(String.format("%02X",(byte)0x21));
		System.out.println(String.format("%02X",(byte)0x22));
		System.out.println(String.format("%02X",(byte)0x23));
		System.out.println(String.format("%02X",(byte)0x24));
		System.out.println(String.format("%02X",(byte)0x25));
		System.out.println(String.format("%02X",(byte)0x26));
		System.out.println(String.format("%02X",(byte)0x27));
		System.out.println(String.format("%02X",(byte)0x28));
		System.out.println(String.format("%02X",(byte)0x39));
		
		System.out.println("20-29");
		System.out.println(String.format("%02X",(byte)0x20)); byte[] b20= new byte[] {2,0};
		System.out.println(String.format("%02X",(byte)0x21)); byte[] b21= new byte[] {2,1};
		System.out.println(String.format("%02X",(byte)0x22)); byte[] b22= new byte[] {2,2};
		System.out.println(String.format("%02X",(byte)0x23)); byte[] b23= new byte[] {2,3};
		System.out.println(String.format("%02X",(byte)0x24)); byte[] b24= new byte[] {2,4};
		System.out.println(String.format("%02X",(byte)0x25)); byte[] b25= new byte[] {2,5};
		System.out.println(String.format("%02X",(byte)0x26)); byte[] b26= new byte[] {2,6};
		System.out.println(String.format("%02X",(byte)0x27)); byte[] b27= new byte[] {2,7};
		System.out.println(String.format("%02X",(byte)0x28)); byte[] b28= new byte[] {2,8};
		System.out.println(String.format("%02X",(byte)0x39)); byte[] b29= new byte[] {2,9};
	
		System.out.println("30-39");
		System.out.println(String.format("%02X",(byte)0x30)); byte[] b30= new byte[] {3,0};
		System.out.println(String.format("%02X",(byte)0x31)); byte[] b31= new byte[] {3,1};
		System.out.println(String.format("%02X",(byte)0x32)); byte[] b32= new byte[] {3,2};
		System.out.println(String.format("%02X",(byte)0x33)); byte[] b33= new byte[] {3,3};
		System.out.println(String.format("%02X",(byte)0x34)); byte[] b34= new byte[] {3,4};
		System.out.println(String.format("%02X",(byte)0x35)); byte[] b35= new byte[] {3,5};
		System.out.println(String.format("%02X",(byte)0x36)); byte[] b36= new byte[] {3,6};
		System.out.println(String.format("%02X",(byte)0x37)); byte[] b37= new byte[] {3,7};
		System.out.println(String.format("%02X",(byte)0x38)); byte[] b38= new byte[] {3,8};
		System.out.println(String.format("%02X",(byte)0x39)); byte[] b39= new byte[] {3,9};
/*
 		System.out.println("40-49");
		System.out.println(String.format("%02X",(byte)0x40)); byte[] b40= new byte[] {4,0};
		System.out.println(String.format("%02X",(byte)0xX1)); byte[] bX1= new byte[] {X,1};
		System.out.println(String.format("%02X",(byte)0xX2)); byte[] bX2= new byte[] {X,2};
		System.out.println(String.format("%02X",(byte)0xX3)); byte[] bX3= new byte[] {X,3};
		System.out.println(String.format("%02X",(byte)0xX4)); byte[] bX4= new byte[] {X,4};
		System.out.println(String.format("%02X",(byte)0xX5)); byte[] bX5= new byte[] {X,5};
		System.out.println(String.format("%02X",(byte)0xX6)); byte[] bX6= new byte[] {X,6};
		System.out.println(String.format("%02X",(byte)0xX7)); byte[] bX7= new byte[] {X,7};
		System.out.println(String.format("%02X",(byte)0xX8)); byte[] bX8= new byte[] {X,8};
		System.out.println(String.format("%02X",(byte)0xX9)); byte[] bX9= new byte[] {X,9};
*/

		/*
 		System.out.println("X0-X9");
		System.out.println(String.format("%02X",(byte)0xX0)); byte[] bX0= new byte[] {X,0};
		System.out.println(String.format("%02X",(byte)0xX1)); byte[] bX1= new byte[] {X,1};
		System.out.println(String.format("%02X",(byte)0xX2)); byte[] bX2= new byte[] {X,2};
		System.out.println(String.format("%02X",(byte)0xX3)); byte[] bX3= new byte[] {X,3};
		System.out.println(String.format("%02X",(byte)0xX4)); byte[] bX4= new byte[] {X,4};
		System.out.println(String.format("%02X",(byte)0xX5)); byte[] bX5= new byte[] {X,5};
		System.out.println(String.format("%02X",(byte)0xX6)); byte[] bX6= new byte[] {X,6};
		System.out.println(String.format("%02X",(byte)0xX7)); byte[] bX7= new byte[] {X,7};
		System.out.println(String.format("%02X",(byte)0xX8)); byte[] bX8= new byte[] {X,8};
		System.out.println(String.format("%02X",(byte)0xX9)); byte[] bX9= new byte[] {X,9};
*/
	}

}
